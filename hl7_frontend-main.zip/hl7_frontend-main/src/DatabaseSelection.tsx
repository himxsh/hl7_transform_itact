import { useState } from 'react';
import { 
  UploadCloud, 
  Plus, 
  Minus, 
  ArrowRight,
  ShieldCheck,
  FileCode
} from 'lucide-react';
import { motion } from 'motion/react';

interface DatabaseSelectionProps {
  onProceed: (config: { dataset: string; sampleSize: number }) => void;
}

export default function DatabaseSelection({ onProceed }: DatabaseSelectionProps) {
  const [selectedDataset, setSelectedDataset] = useState('MIMIC-IV v3.1');
  const [sampleSize, setSampleSize] = useState(50);

  const datasets = [
    {
      id: 'MIMIC-IV v3.1',
      title: 'MIMIC-IV v3.1',
      source: 'PHYSIONET',
      recommended: true,
      tags: ['DPDP', 'IT ACT'],
      description: 'De-identified electronic health records from ICU patients. The pipeline performs a multi-stage LEFT JOIN across labevents, d_labitems, and patients to produce the denormalized view required for HL7 segment generation.',
      stats: [
        { label: 'SOURCE FILES', value: 'patients.csv.gz · labevents.csv.gz · d_labitems.csv.gz' },
        { label: 'LAB EVENTS', value: '~158M rows (chunked stream)' },
        { label: 'PRIVACY MODE', value: 'birth_year derived' },
        { label: 'PSEUDONYMISER', value: 'Faker(en_IN)' },
      ]
    },
    {
      id: 'ILPD',
      title: 'Indian Liver Patient Dataset',
      source: 'UCI Machine Learning Repository',
      recommended: false,
      tags: [],
      description: 'Flat CSV of liver function test values ingested via the generic CSV mode. A declarative JSON mapping registry translates column headers into internal clinical attributes such as Bilirubin and BUN.',
      stats: [
        { label: 'FORMAT', value: 'Flat CSV' },
        { label: 'RECORDS', value: '583 Clinical Rows' },
        { label: 'MAPPED ATTRIBUTES', value: 'Bilirubin · BUN · ALT · AST · Albumin' },
        { label: 'JOIN STRATEGY', value: 'Single Table' },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-bg-light text-neutral-dark font-sans selection:bg-primary-gold/30">
      <div className="max-w-[960px] mx-auto flex flex-col items-center">
        {/* Navigation */}
        <header className="w-full flex items-center justify-between border-b border-primary-gold/10 px-6 py-6">
          <div className="flex items-center gap-3">
            <div className="text-primary-gold">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                <path d="M13.8261 30.5736C16.7203 29.8826 20.2244 29.4783 24 29.4783C27.7756 29.4783 31.2797 29.8826 34.1739 30.5736C36.9144 31.2278 39.9967 32.7669 41.3563 33.8352L24.8486 7.36089C24.4571 6.73303 23.5429 6.73303 23.1514 7.36089L6.64374 33.8352C8.00331 32.7669 11.0856 31.2278 13.8261 30.5736Z" fill="currentColor"></path>
                <path clipRule="evenodd" d="M39.998 35.764C39.9944 35.7463 39.9875 35.7155 39.9748 35.6706C39.9436 35.5601 39.8949 35.4259 39.8346 35.2825C39.8168 35.2403 39.7989 35.1993 39.7813 35.1602C38.5103 34.2887 35.9788 33.0607 33.7095 32.5189C30.9875 31.8691 27.6413 31.4783 24 31.4783C20.3587 31.4783 17.0125 31.8691 14.2905 32.5189C12.0012 33.0654 9.44505 34.3104 8.18538 35.1832C8.17384 35.2075 8.16216 35.233 8.15052 35.2592C8.09919 35.3751 8.05721 35.4886 8.02977 35.589C8.00356 35.6848 8.00039 35.7333 8.00004 35.7388C8.00004 35.739 8 35.7393 8.00004 35.7388C8.00004 35.7641 8.0104 36.0767 8.68485 36.6314C9.34546 37.1746 10.4222 37.7531 11.9291 38.2772C14.9242 39.319 19.1919 40 24 40C28.8081 40 33.0758 39.319 36.0709 38.2772C37.5778 37.7531 38.6545 37.1746 39.3151 36.6314C39.9006 36.1499 39.9857 35.8511 39.998 35.764ZM4.95178 32.7688L21.4543 6.30267C22.6288 4.4191 25.3712 4.41909 26.5457 6.30267L43.0534 32.777C43.0709 32.8052 43.0878 32.8338 43.104 32.8629L41.3563 33.8352C43.104 32.8629 43.1038 32.8626 43.104 32.8629L43.1051 32.865L43.1065 32.8675L43.1101 32.8739L43.1199 32.8918C43.1276 32.906 43.1377 32.9246 43.1497 32.9473C43.1738 32.9925 43.2062 33.0545 43.244 33.1299C43.319 33.2792 43.4196 33.489 43.5217 33.7317C43.6901 34.1321 44 34.9311 44 35.7391C44 37.4427 43.003 38.7775 41.8558 39.7209C40.6947 40.6757 39.1354 41.4464 37.385 42.0552C33.8654 43.2794 29.133 44 24 44C18.867 44 14.1346 43.2794 10.615 42.0552C8.86463 41.4464 7.30529 40.6757 6.14419 39.7209C4.99695 38.7775 3.99999 37.4427 3.99999 35.7391C3.99999 34.8725 4.29264 34.0922 4.49321 33.6393C4.60375 33.3898 4.71348 33.1804 4.79687 33.0311C4.83898 32.9556 4.87547 32.8935 4.9035 32.8471C4.91754 32.8238 4.92954 32.8043 4.93916 32.7889L4.94662 32.777L4.95178 32.7688ZM35.9868 29.004L24 9.77997L12.0131 29.004C12.4661 28.8609 12.9179 28.7342 13.3617 28.6282C16.4281 27.8961 20.0901 27.4783 24 27.4783C27.9099 27.4783 31.5719 27.8961 34.6383 28.6282C35.082 28.7342 35.5339 28.8609 35.9868 29.004Z" fill="currentColor" fillRule="evenodd"></path>
              </svg>
            </div>
            <h2 className="text-neutral-dark text-lg font-display font-semibold tracking-tight uppercase">HL7 Orchestrator</h2>
          </div>
          <nav className="hidden md:flex items-center gap-10">
            <button className="text-neutral-dark text-xs font-sans uppercase tracking-widest hover:text-primary-gold transition-colors">Pipeline</button>
            <button className="text-neutral-dark text-xs font-sans uppercase tracking-widest hover:text-primary-gold transition-colors">Architecture</button>
            <button className="text-neutral-dark text-xs font-sans uppercase tracking-widest hover:text-primary-gold transition-colors border-b border-primary-gold pb-0.5">Database</button>
            <button className="text-neutral-dark text-xs font-sans uppercase tracking-widest hover:text-primary-gold transition-colors">Compliance</button>
          </nav>
        </header>

        {/* Main Content */}
        <main className="w-full max-w-[860px] px-6 py-20 flex flex-col items-center">
          <span className="font-mono text-[10px] text-primary-gold/80 mb-6 uppercase tracking-[0.1em]">Step 1 of 2</span>
          <h1 className="font-title text-5xl md:text-[52px] text-neutral-dark text-center leading-tight mb-4">Select a Data Source</h1>
          <p className="font-sans text-sm text-neutral-dark/60 text-center max-w-lg mb-8 leading-relaxed">
            The pipeline supports two clinical datasets natively, optimized for multi-modal health record synchronization and high-fidelity pseudonymization.
          </p>
          
          {/* Gold Divider */}
          <div className="w-[48px] h-[1px] bg-primary-gold mb-16"></div>

          {/* Card Stack */}
          <div className="w-full flex flex-col gap-6">
            {datasets.map((dataset) => (
              <motion.div 
                key={dataset.id}
                onClick={() => setSelectedDataset(dataset.id)}
                whileHover={{ y: -4 }}
                className={`group relative bg-white border p-8 rounded-sm transition-all cursor-pointer ${
                  selectedDataset === dataset.id 
                    ? 'border-primary-gold shadow-[0_10px_40px_-15px_rgba(193,175,134,0.2)]' 
                    : 'border-primary-gold/20 hover:shadow-[0_10px_40px_-15px_rgba(193,175,134,0.15)]'
                }`}
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    {dataset.recommended && (
                      <span className="font-mono text-[9px] bg-primary-gold/10 text-primary-gold px-2 py-1 mb-3 inline-block tracking-[0.1em]">RECOMMENDED</span>
                    )}
                    {!dataset.recommended && (
                      <span className="font-mono text-[9px] bg-neutral-dark/5 text-neutral-dark/60 px-2 py-1 mb-3 inline-block uppercase tracking-[0.1em]">Dataset Neutral Mode</span>
                    )}
                    <h3 className={`font-title text-3xl text-neutral-dark transition-all ${selectedDataset === dataset.id ? 'italic' : 'group-hover:italic'}`}>
                      {dataset.title}
                    </h3>
                    <p className="font-sans text-[11px] uppercase tracking-widest text-neutral-dark/40 mt-1">{dataset.source}</p>
                  </div>
                  <div className="flex gap-2">
                    {dataset.tags.map(tag => (
                      <span key={tag} className="font-mono text-[9px] border border-primary-gold/20 px-2 py-1 text-neutral-dark/60 tracking-[0.1em]">{tag}</span>
                    ))}
                  </div>
                </div>
                <p className="font-sans text-sm text-neutral-dark/70 mb-8 max-w-2xl leading-relaxed">
                  {dataset.description}
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 border-t border-primary-gold/10 pt-6">
                  {dataset.stats.map(stat => (
                    <div key={stat.label} className="flex flex-col">
                      <span className="font-mono text-[9px] text-primary-gold/60 uppercase tracking-[0.1em]">{stat.label}</span>
                      <span className="font-sans text-[10px] mt-1 line-clamp-2">{stat.value}</span>
                    </div>
                  ))}
                </div>
                
                {/* Selection Indicator */}
                {selectedDataset === dataset.id && (
                  <div className="absolute top-4 right-4 text-primary-gold">
                    <ShieldCheck size={20} />
                  </div>
                )}
              </motion.div>
            ))}

            {/* Card 3: Upload */}
            <motion.div 
              whileHover={{ y: -4 }}
              className="group relative bg-white border border-dashed border-primary-gold/40 p-8 rounded-sm hover:bg-primary-gold/5 transition-all cursor-pointer"
            >
              <div className="flex flex-col items-center text-center">
                <span className="font-mono text-[9px] text-primary-gold/60 px-2 py-1 mb-4 border border-primary-gold/20 inline-block uppercase tracking-widest">Bring Your Own</span>
                <h3 className="font-title text-3xl text-neutral-dark italic mb-2">Upload a CSV</h3>
                <p className="font-sans text-[11px] uppercase tracking-widest text-neutral-dark/40 mb-6">Custom local dataset integration</p>
                <div className="w-full py-12 border border-dashed border-primary-gold/20 flex flex-col items-center justify-center bg-bg-light/50 rounded-sm">
                  <UploadCloud className="text-primary-gold mb-3 font-light" size={32} />
                  <p className="font-sans text-xs text-neutral-dark/60 uppercase tracking-widest">Drag and drop file or <span className="text-primary-gold underline cursor-pointer">browse</span></p>
                </div>
                <p className="font-sans text-[10px] text-neutral-dark/40 mt-6 max-w-sm">Supported formats: .csv files only · max 500MB.</p>
              </div>
            </motion.div>
          </div>

          {/* Controls */}
          <div className="mt-20 flex flex-col items-center gap-10 w-full">
            <div className="flex flex-col items-center gap-4">
              <span className="font-mono text-[10px] text-primary-gold/60 uppercase tracking-[0.1em]">INITIAL SAMPLE SIZE</span>
              <div className="flex items-center gap-8 border-b border-primary-gold/20 pb-2">
                <button 
                  onClick={() => setSampleSize(Math.max(1, sampleSize - 10))}
                  className="text-primary-gold hover:text-neutral-dark transition-colors"
                >
                  <Minus size={16} />
                </button>
                <input 
                  className="bg-transparent border-none text-center font-sans text-xl w-24 focus:ring-0 text-neutral-dark" 
                  type="text" 
                  value={sampleSize}
                  onChange={(e) => setSampleSize(parseInt(e.target.value) || 0)}
                />
                <button 
                  onClick={() => setSampleSize(sampleSize + 10)}
                  className="text-primary-gold hover:text-neutral-dark transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
            <button 
              onClick={() => onProceed({ dataset: selectedDataset, sampleSize })}
              className="bg-neutral-dark text-white font-sans text-xs tracking-[0.2em] uppercase px-16 py-6 rounded-sm hover:bg-neutral-dark/90 transition-all flex items-center gap-3 group"
            >
              <span>Proceed to Dashboard</span>
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </main>

        {/* Footer */}
        <footer className="w-full max-w-[860px] px-6 py-12 border-t border-primary-gold/10 flex justify-between items-center text-neutral-dark/40">
          <div className="font-mono text-[9px] uppercase tracking-[0.1em]">© 2024 HL7 Orchestrator Systems</div>
        </footer>
      </div>
    </div>
  );
}
